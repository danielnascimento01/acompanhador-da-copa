# 7a0 — Sete a Zero · Pacote completo para recriar o jogo

Tudo que é necessário para reconstruir o jogo **7a0 (Sete a Zero)**: a especificação de mecânica, os dados reais (seleções, Copas, elencos, jogadores e ratings) e um motor de simulação funcional, fiel ao original, com os números de balanceamento exatos.

O "7 a 0" não é um placar de 7x0 numa partida. É uma **campanha perfeita**: 7 vitórias e 0 tropeços (3 jogos de grupo + oitavas + quartas + semi + final = 7 jogos).

---

## Estrutura

```
prompt-7a0-sete-a-zero.md      Especificação completa de mecânica e arquitetura (o "prompt de build")
elencos_7a0_referencia.md      Referência legível: todos os 250 elencos com jogadores e ratings
README.md                      Este arquivo

dados/
  catalog.json                 250 elencos disponíveis: { sel, nome, copa, slug }
  formacoes.json               8 formações x 3 táticas, com posições e coordenadas (x,y) no campo
  base_7a0_completa.json       Base consolidada: todos os elencos e jogadores num só arquivo
  jogadores_7a0.csv            Todos os 5.613 jogadores em CSV (para análise no Excel/planilha)
  squads/
    {slug}.json  (x250)        Um arquivo por elenco, no padrão que o jogo serve em /squads/{slug}.json

engine/                        Motor de simulação funcional (JavaScript / ES Modules)
  config.js                    Constantes reais: pesos por posição, fases, modelo de gols, pênaltis, modos
  rng.js                       RNG determinístico (xmur3 -> mulberry32), Poisson, escolha ponderada
  team.js                      Cálculo de força do time (attack / defense / overall)
  sim.js                       Simulação de partida e de campanha (grupos, mata-mata, pênaltis, badges)
  draft.js                     Máquina de estados do draft (rolar, re-sortear, escalar, mover)
  demo.js                      Exemplo executável de ponta a ponta
```

---

## Como rodar o motor

Precisa de Node 18+ (testado no Node 22). Na raiz do pacote:

```bash
node engine/demo.js minha-seed
```

O demo monta um time automaticamente (pega o melhor jogador disponível a cada sorteio), calcula as forças, simula uma Copa inteira e imprime o resultado. Troque a seed para gerar outra campanha. A mesma seed sempre produz o mesmo resultado (determinístico), que é o que permite os códigos de compartilhamento e o modo com amigos.

---

## Os dados

- **52 seleções · 250 elencos · 5.613 jogadores · 20 Copas (1950 a 2026).**
- Cada jogador: `{ playerId, name/n, positions/pos[], r (rating 0-99), num (camisa), leg (lenda) }`.
- Os ratings são uma "foto" do jogador naquele torneio específico, não a carreira inteira. Topo da escala (99): Yashin 1958, Pelé 1970, Maradona 1986, Neuer 2014, Messi 2022.
- A flag `leg` (lenda) marca o craque histórico de cada elenco.
- **Nota:** o site oficial anuncia ~5.729 jogadores; esta base traz 5.613, que é o conteúdo servido na versão capturada. A diferença não afeta a mecânica.

### Slugs
Formato `SEL-ANO-hash`, ex: `BRA-1970-4b0e863a`. O `catalog.json` lista todos. Para servir como o jogo faz, exponha cada arquivo em `dados/squads/{slug}.json`.

---

## As 12 posições

`GOL` goleiro · `LD` lateral direito · `ZAG` zagueiro · `LE` lateral esquerdo · `VOL` volante · `MD` meia direita · `MC` meio-campo central · `ME` meia esquerda · `MEI` meia ofensivo · `PD` ponta direita · `CA` centroavante · `PE` ponta esquerda.

## Núcleo do balanceamento

Cada posição tem peso de ataque e de defesa (em `config.js`). Atacante pesa 1 no ataque e 0 na defesa; zagueiro o contrário. A tática (defensivo / equilibrado / ofensivo) troca a composição de posições da formação, e isso muda o ataque e a defesa do time. Os placares saem de um modelo de Poisson cujo lambda depende da diferença de força entre o seu time e o adversário. Adversários ficam mais fortes a cada fase (overall 68 nos grupos até 91 na final).

Todos os valores exatos estão em `engine/config.js` e descritos em `prompt-7a0-sete-a-zero.md`.

---

## Ordem sugerida para reconstruir

1. Suba os dados (`dados/`) como arquivos estáticos ou num banco.
2. Porte o motor (`engine/`) para a sua stack (já é JS puro, roda no navegador ou no servidor).
3. Construa a UI: tela inicial, draft (rolar dado, escolher jogador, montar 11), campo com as coordenadas de `formacoes.json`, e a tela de resultado com a campanha jogo a jogo.
4. Adicione códigos de compartilhamento (compõe o time + seed) e o modo com amigos (duas seleções, mesma engine de partida).
5. i18n em pt / en / es.

Tudo o que não estiver aqui (texto de UI, layout visual fino) é escolha livre de produto. A mecânica, os números e os dados, que são o que define o jogo, estão completos neste pacote.

// rng.js — Gerador de números pseudo-aleatórios determinístico (fiel ao original)
// xmur3 (hash da seed) -> mulberry32 (PRNG). A mesma seed produz sempre a mesma sequência.

export function makeRng(seedStr) {
  // hash xmur3
  let h = 0x6a09e667 ^ seedStr.length;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(h ^ seedStr.charCodeAt(i), 0xcc9e2d51);
    h = (h << 13) | (h >>> 19);
  }
  let a = h >>> 0;
  // PRNG mulberry32
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 0x100000000;
  };
}

// Escolha uniforme
export function pick(rng, arr) {
  if (arr.length === 0) throw new Error('pick: array vazio');
  return arr[Math.floor(rng() * arr.length)];
}

// Escolha ponderada
export function pickWeighted(rng, items, weights) {
  if (items.length === 0) throw new Error('pickWeighted: array vazio');
  const total = weights.reduce((s, w) => s + w, 0);
  let r = rng() * total;
  for (let i = 0; i < items.length; i++) {
    if ((r -= weights[i]) <= 0) return items[i];
  }
  return items[items.length - 1];
}

// Amostragem de Poisson (algoritmo de Knuth)
export function poisson(rng, lam) {
  if (lam <= 0) return 0;
  const L = Math.exp(-lam);
  let k = 0, p = 1;
  do { k++; p *= rng(); } while (p > L);
  return k - 1;
}

// Desofuscação do rating (caso você sirva os dados com o campo `f` ofuscado, como o original)
export function deobfuscateForce(fStored, playerId) {
  let h = 0x811c9dc5;
  const key = playerId + '7a0::alm::v1';
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (fStored ^ ((h >>> 0) & 255)) & 255;
}

// draft.js — Máquina de estados do draft (sorteio e montagem do time)
import { makeRng, pickWeighted } from './rng.js';
import { getSlots } from './team.js';
import { MODOS, PADROES } from './config.js';

// Cria um draft novo
export function novoDraft({ seed, catalogo, formation = PADROES.formation, style = PADROES.style, mode = PADROES.mode }) {
  const slots = getSlots(formation, style);
  return {
    seed,
    catalogo,                 // [{ sel, nome, copa, slug }]
    formation, style, mode,
    slots,                    // 11 slots { pos, x, y }
    filled: slots.map(() => null), // jogador em cada slot (ou null)
    usedPlayerIds: [],
    rollIndex: 0,
    rerollNo: 0,
    rerollsLeft: MODOS[mode].rerolls,
    current: null,            // { sel, nome, copa, slug } sorteado na rodada atual
    recent: [],               // últimos sorteios (para evitar repetição imediata)
  };
}

// Rola o dado: sorteia uma dupla (seleção, copa) ponderada, evitando repetir as recentes.
export function rolar(draft) {
  const rng = makeRng(`${draft.seed}:roll:${draft.rollIndex}`);
  const recent = new Set(draft.recent.map(c => `${c.sel}:${c.copa}`));
  const disp = draft.catalogo.filter(c => !recent.has(`${c.sel}:${c.copa}`));
  const pool = disp.length ? disp : draft.catalogo;
  // peso uniforme por padrão; ajuste aqui se quiser ponderar por época/relevância
  const pesos = pool.map(() => 1);
  const current = pickWeighted(rng, pool, pesos);
  return {
    ...draft,
    current,
    rollIndex: draft.rollIndex + 1,
    rerollNo: 0,
    recent: [current, ...draft.recent].slice(0, 4),
  };
}

// Re-sorteia (gasta um re-sorteio). axis: 'selecao' | 'copa'
export function reSortear(draft, axis = 'selecao') {
  if (!draft.current) throw new Error('Role primeiro');
  if (draft.rerollsLeft <= 0) throw new Error('Sem re-sorteios restantes');
  const rng = makeRng(`${draft.seed}:roll:${draft.rollIndex}:rr:${draft.rerollNo}:${axis}`);
  const recent = new Set(draft.recent.map(c => `${c.sel}:${c.copa}`));
  let pool = draft.catalogo.filter(c => !recent.has(`${c.sel}:${c.copa}`));
  if (axis === 'selecao') pool = pool.filter(c => c.copa === draft.current.copa);
  if (axis === 'copa')    pool = pool.filter(c => c.sel  === draft.current.sel);
  if (!pool.length) pool = draft.catalogo;
  const current = pickWeighted(rng, pool, pool.map(() => 1));
  return {
    ...draft,
    current,
    rerollNo: draft.rerollNo + 1,
    rerollsLeft: draft.rerollsLeft - 1,
    recent: [current, ...draft.recent].slice(0, 4),
  };
}

// Posições ainda vagas
export function vagasAbertas(draft) {
  return draft.slots
    .map((s, i) => ({ ...s, i }))
    .filter((s, i) => draft.filled[i] === null);
}

// Quais jogadores de um elenco podem entrar (cobrem alguma vaga e ainda não foram usados)
export function selecionaveis(draft, squad) {
  const usados = new Set(draft.usedPlayerIds);
  const vagas = new Set(vagasAbertas(draft).map(s => s.pos));
  return squad.map(p => ({
    player: p,
    selectable: !usados.has(p.playerId ?? p.n) && p.pos.some(pos => vagas.has(pos)),
  }));
}

// Escala um jogador num slot específico
export function escalar(draft, player, slotIndex) {
  const id = player.playerId ?? player.n;
  if (draft.usedPlayerIds.includes(id)) throw new Error('Jogador já usado: ' + player.n);
  const slot = draft.slots[slotIndex];
  if (!slot || draft.filled[slotIndex] !== null) throw new Error('Vaga inválida ou ocupada');
  if (!player.pos.includes(slot.pos)) throw new Error(`${player.n} não joga ${slot.pos}`);
  const filled = draft.filled.slice();
  filled[slotIndex] = player;
  return { ...draft, filled, usedPlayerIds: [...draft.usedPlayerIds, id], current: null };
}

// Time completo?
export function completo(draft) {
  return draft.filled.every(p => p !== null);
}

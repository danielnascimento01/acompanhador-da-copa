// config.js — Constantes do 7a0 (valores reais extraídos do jogo original)

// Pesos de cada posição no ataque e na defesa do time.
// Trocar a tática muda quais posições entram em campo, e isso muda attack/defense.
export const PESO_ATAQUE = {
  GOL: 0,   LD: 0,   ZAG: 0,  LE: 0,
  MD: 0.5,  ME: 0.5, VOL: 0.2, MC: 0.5, MEI: 0.8,
  PD: 1,    CA: 1,   PE: 1,
};

export const PESO_DEFESA = {
  GOL: 1,   LD: 1,   ZAG: 1,  LE: 1,
  MD: 0.5,  ME: 0.5, VOL: 0.8, MC: 0.5, MEI: 0.2,
  PD: 0,    CA: 0,   PE: 0,
};

// Modos de jogo
export const MODOS = {
  classico:  { rerolls: 3, statsVisible: true },   // ratings visíveis
  almanaque: { rerolls: 1, statsVisible: false },  // ratings ocultos (memória)
};

export const PADROES = {
  formation: '4-3-3',
  style: 'equilibrado',   // 'defensivo' | 'equilibrado' | 'ofensivo'
  mode: 'classico',
};

// Eixos que o re-sorteio pode trocar
export const REROLL_AXES = ['selecao', 'copa'];

// Estrutura do torneio: 3 jogos de grupo + 4 eliminatórias. Overall do adversário sobe por fase.
export const FASES = [
  { key: 'GRUPOS', type: 'group', opponents: [
    { label: 'Grupo · 1º jogo', overall: 68 },
    { label: 'Grupo · 2º jogo', overall: 72 },
    { label: 'Grupo · 3º jogo', overall: 76 },
  ]},
  { key: 'OITAVAS', type: 'knockout', opponent: { label: 'Oitavas',   overall: 79 } },
  { key: 'QUARTAS', type: 'knockout', opponent: { label: 'Quartas',   overall: 83 } },
  { key: 'SEMI',    type: 'knockout', opponent: { label: 'Semifinal', overall: 87 } },
  { key: 'FINAL',   type: 'knockout', opponent: { label: 'Final',     overall: 91 } },
];

// Modelo de gols (Poisson) e disputa de pênaltis
export const MODELO  = { baseLambda: 1.4, slope: 0.08, minLambda: 0.15, maxLambda: 5 };
export const PENALTI = { base: 0.5, slope: 0.012, min: 0.1, max: 0.9 };
export const BADGE   = { esmagadorGD: 18 };

// Conversão por cobrança na encenação dos pênaltis
export const PENALTI_CONVERSAO = 0.78;

// sim.js — Motor de simulação de partida e de campanha de Copa
import { makeRng, poisson } from './rng.js';
import { FASES, MODELO, PENALTI, BADGE, PENALTI_CONVERSAO } from './config.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// Gols esperados de um lado (força atacante) contra o outro (força defensiva adversária)
function lambda(forcaAtacante, forcaDefensorAdv) {
  const { baseLambda, slope, minLambda, maxLambda } = MODELO;
  return clamp(baseLambda + (forcaAtacante - forcaDefensorAdv) * slope, minLambda, maxLambda);
}

// Uma partida: meu attack/defense contra o overall do adversário.
// outcome: 'V' (vitória) | 'E' (empate) | 'D' (derrota)
export function simularPartida(rng, attack, defense, advOverall) {
  const gf = poisson(rng, lambda(attack, advOverall));
  const ga = poisson(rng, lambda(advOverall, defense));
  return { gf, ga, outcome: gf > ga ? 'V' : gf < ga ? 'D' : 'E' };
}

// Probabilidade de vencer a disputa de pênaltis (função da diferença de overall)
function probPenaltis(meuOverall, advOverall) {
  const { base, slope, min, max } = PENALTI;
  return clamp(base + (meuOverall - advOverall) * slope, min, max);
}

// Encenação cobrança a cobrança, coerente com o vencedor já decidido.
function encenarPenaltis(rng, euVenci) {
  const kicks = [];
  let me = 0, opp = 0;
  for (let i = 0; i < 5; i++) {
    kicks.push({ lado: 'eu',  marcou: rng() < PENALTI_CONVERSAO });
    kicks.push({ lado: 'adv', marcou: rng() < PENALTI_CONVERSAO });
  }
  kicks.forEach(k => { if (k.marcou) (k.lado === 'eu' ? me++ : opp++); });
  // ajusta o placar final para refletir o vencedor predeterminado (morte súbita simplificada)
  if (euVenci && me <= opp) me = opp + 1;
  if (!euVenci && me >= opp) opp = me + 1;
  return { kicks, placar: euVenci ? `${me}-${opp}` : `${me}-${opp}`, vencedorEu: euVenci };
}

// Gera minutos de gol (1-90) e marca quem é do adversário (oppGoals).
function gerarMinutos(rng, gf, ga) {
  const minutos = [];
  const sorteia = (qtd, opp) => {
    const set = new Set();
    let guard = 0;
    while (set.size < qtd && guard++ < 1000) {
      set.add(1 + Math.floor(90 * Math.pow(rng(), 0.85)));
    }
    [...set].forEach(min => minutos.push({ min, opp }));
  };
  sorteia(gf, false);
  sorteia(ga, true);
  return minutos.sort((a, b) => a.min - b.min);
}

// Simula a campanha inteira. `forcas` = { attack, defense, overall }. `seed` = string base.
export function simularCampanha(forcas, seed) {
  const { attack, defense, overall } = forcas;
  const rng = makeRng(`${seed}:copa`);
  const campaign = [];
  let wins = 0, draws = 0, losses = 0, gf = 0, ga = 0, eliminado = false;

  for (const fase of FASES) {
    if (eliminado) break;

    if (fase.type === 'group') {
      const resultados = [];
      for (const opp of fase.opponents) {
        const m = simularPartida(rng, attack, defense, opp.overall);
        gf += m.gf; ga += m.ga;
        if (m.outcome === 'V') wins++; else if (m.outcome === 'E') draws++; else losses++;
        resultados.push(m);
        campaign.push({
          phase: fase.key, opp: opp.label, oppOverall: opp.overall,
          gf: m.gf, ga: m.ga, outcome: m.outcome, advanced: true,
          goals: gerarMinutos(rng, m.gf, m.ga),
        });
      }
      // tabela do grupo: pontos (3/1/0), saldo, gols feitos. Avança se top 2.
      const meus = {
        pts: resultados.reduce((s, r) => s + (r.outcome === 'V' ? 3 : r.outcome === 'E' ? 1 : 0), 0),
        gd:  resultados.reduce((s, r) => s + (r.gf - r.ga), 0),
        gf:  resultados.reduce((s, r) => s + r.gf, 0),
        me: true,
      };
      // adversários do grupo jogam entre si (simulação simplificada por overall)
      const outros = fase.opponents.map((o, idx) => ({ pts: 0, gd: 0, gf: 0, me: false, overall: o.overall, idx }));
      for (let i = 0; i < outros.length; i++) {
        for (let j = i + 1; j < outros.length; j++) {
          const r = simularPartida(rng, outros[i].overall, outros[i].overall, outros[j].overall);
          if (r.outcome === 'V') outros[i].pts += 3;
          else if (r.outcome === 'E') { outros[i].pts++; outros[j].pts++; }
          else outros[j].pts += 3;
          outros[i].gd += r.gf - r.ga; outros[i].gf += r.gf;
          outros[j].gd += r.ga - r.gf; outros[j].gf += r.ga;
        }
      }
      const tabela = [meus, ...outros].sort((a, b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf);
      const avancou = tabela.findIndex(t => t.me) < 2;
      campaign[campaign.length - 1].groupTable = tabela;
      if (!avancou) eliminado = true;
      continue;
    }

    // eliminatória
    const opp = fase.opponent;
    const m = simularPartida(rng, attack, defense, opp.overall);
    gf += m.gf; ga += m.ga;
    let avancou;
    let pens;
    if (m.outcome === 'V') avancou = true;
    else if (m.outcome === 'D') avancou = false;
    else {
      // empate -> pênaltis
      avancou = rng() < probPenaltis(overall, opp.overall);
      pens = encenarPenaltis(rng, avancou);
    }
    if (avancou) wins++; else losses++;
    campaign.push({
      phase: fase.key, opp: opp.label, oppOverall: opp.overall,
      gf: m.gf, ga: m.ga, outcome: m.outcome, advanced: avancou,
      penalties: m.outcome === 'E', pens,
      goals: gerarMinutos(rng, m.gf, m.ga),
    });
    if (!avancou) eliminado = true;
  }

  const champion = !eliminado;
  const perfect  = champion && wins === 7 && draws === 0 && losses === 0; // o "7 a 0"
  const muralha  = champion && ga === 0;
  let badge = null;
  if (perfect && (gf - ga) >= BADGE.esmagadorGD) badge = 'ESMAGADOR DE RECORDES';
  else if (muralha) badge = 'MURALHA';

  return { record: `${wins}-${losses}`, champion, perfect, wins, draws, losses, gf, ga, badge, campaign };
}

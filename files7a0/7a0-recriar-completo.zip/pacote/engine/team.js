// team.js — Cálculo da força do time a partir da formação/tática e dos 11 jogadores
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PESO_ATAQUE, PESO_DEFESA } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const formacoes = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'dados', 'formacoes.json'), 'utf8'));

// Retorna os 11 slots de uma formação/tática. Cada slot: { pos, x, y }
export function getSlots(formation, style = 'equilibrado') {
  const f = formacoes[formation];
  if (!f) throw new Error('Formação inválida: ' + formation);
  return f[style] || f.equilibrado;
}

// attack / defense = média dos ratings ponderada pelo peso ofensivo/defensivo de cada posição.
// overall = média simples dos 11.
// `jogadores` é um array alinhado aos slots (mesmo índice). Posições vazias = null.
export function calcForcas(slots, jogadores) {
  let an = 0, ad = 0, dn = 0, dd = 0, soma = 0, n = 0;
  slots.forEach((slot, i) => {
    const p = jogadores[i];
    const wa = PESO_ATAQUE[slot.pos] ?? 0;
    const wd = PESO_DEFESA[slot.pos] ?? 0;
    ad += wa;
    dd += wd;
    if (p) {
      const r = p.r ?? p.force ?? 0;
      an += r * wa;
      dn += r * wd;
      soma += r;
      n++;
    }
  });
  return {
    attack:  ad > 0 ? Math.round(an / ad) : 0,
    defense: dd > 0 ? Math.round(dn / dd) : 0,
    overall: n  > 0 ? Math.round(soma / n) : 0,
  };
}

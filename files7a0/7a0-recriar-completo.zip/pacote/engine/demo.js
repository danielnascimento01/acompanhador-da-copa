// demo.js — Exemplo executável de ponta a ponta. Rode com: node engine/demo.js
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { novoDraft, rolar, reSortear, selecionaveis, escalar, vagasAbertas, completo } from './draft.js';
import { calcForcas } from './team.js';
import { simularCampanha } from './sim.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DADOS = path.join(__dirname, '..', 'dados');

const catalogo = JSON.parse(fs.readFileSync(path.join(DADOS, 'catalog.json'), 'utf8'));
const carregarElenco = (slug) => JSON.parse(fs.readFileSync(path.join(DADOS, 'squads', `${slug}.json`), 'utf8'));

// Estratégia automática: rola, e do elenco sorteado pega o melhor jogador que cabe numa vaga aberta.
function montarTimeAuto(seed) {
  let d = novoDraft({ seed, catalogo, formation: '4-3-3', style: 'ofensivo', mode: 'classico' });
  let tentativas = 0;
  while (!completo(d) && tentativas < 500) {
    tentativas++;
    d = rolar(d);
    const elenco = carregarElenco(d.current.slug);
    const opcoes = selecionaveis(d, elenco.squad).filter(o => o.selectable);
    if (!opcoes.length) continue; // nenhum jogador serve, rola de novo
    // melhor jogador disponível
    opcoes.sort((a, b) => (b.player.r ?? 0) - (a.player.r ?? 0));
    const melhor = opcoes[0].player;
    // primeira vaga aberta que o jogador cobre
    const vaga = vagasAbertas(d).find(s => melhor.pos.includes(s.pos));
    d = escalar(d, melhor, vaga.i);
  }
  return d;
}

const seed = process.argv[2] || 'demo-7a0';
const draft = montarTimeAuto(seed);
const forcas = calcForcas(draft.slots, draft.filled);

console.log(`\n=== TIME MONTADO (seed: "${seed}", 4-3-3 ofensivo) ===`);
draft.slots.forEach((s, i) => {
  const p = draft.filled[i];
  console.log(`  ${s.pos.padEnd(4)} ${p ? `${p.n} (${p.r})` : '—'}`);
});
console.log(`\nForças -> ATAQUE ${forcas.attack} · DEFESA ${forcas.defense} · OVERALL ${forcas.overall}`);

const res = simularCampanha(forcas, seed);
console.log(`\n=== CAMPANHA ===`);
res.campaign.forEach(j => {
  const pen = j.penalties ? ` (pênaltis ${j.pens?.placar ?? ''})` : '';
  console.log(`  ${j.phase.padEnd(8)} vs ${j.opp.padEnd(16)} ${j.gf}x${j.ga} [${j.outcome}]${pen}`);
});
console.log(`\nResultado: ${res.record}  |  Campeão: ${res.champion ? 'SIM' : 'não'}  |  7 a 0: ${res.perfect ? 'SIM 🏆' : 'não'}`);
console.log(`Gols: ${res.gf} pró / ${res.ga} contra${res.badge ? `  |  BADGE: ${res.badge}` : ''}`);
